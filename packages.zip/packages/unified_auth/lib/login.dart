import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:unified_auth/repo/button.dart';
import 'package:unified_auth/repo/textfield.dart';

import 'repo/bg_container.dart';

class LoginAuth extends HookWidget {
  /// The background image for the login screen. Should be a SVG image.
  final String background;

  /// The controller for the username field.
  final TextEditingController usernameController;

  /// The controller for the password field.
  final TextEditingController passwordController;

  /// The logo image for the login screen. Should be a SVG image.
  final String logo;

  /// Validator for usernme textfield
  final String? Function(String?)? usernameValidator;

  /// Validator for password textfield
  final String? Function(String?)? passwordValidator;

  /// Callback for when the login button is pressed.
  final ValueChanged<(String, String)>? onLogin;

  /// Hint text for username textfield
  final String? usernameHintText;

  /// Hint text for password textfield
  final String? passwordHintText;

  /// Callback for when the register button is pressed.
  final VoidCallback onSupplierRegister;

  /// Callback for when the user register button is pressed.
  final VoidCallback onUserRegister;
  const LoginAuth(
      {required this.logo,
      required this.background,
      required this.usernameController,
      required this.passwordController,
      required this.usernameValidator,
      required this.passwordValidator,
      required this.usernameHintText,
      required this.passwordHintText,
      required this.onLogin,
      required this.onUserRegister,
      required this.onSupplierRegister,
      Key? key})
      : super(key: key);

  @override
  Widget build(
    BuildContext context,
  ) {
    final formKey = useMemoized(() => GlobalKey<FormState>());

    return Scaffold(
        body: BackgroundContainer(
      background: background,
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          width: MediaQuery.sizeOf(context).height > 400 ? 275 + 25 : 275,
          child: Form(
            key: formKey,
            child: AutofillGroup(
                child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (logo.toString().contains(".svg")) ...[
                  SvgPicture.asset(logo,
                      fit: BoxFit.fill, height: 230, width: 230),
                ],
                if (logo.toString().contains(".png")) ...[
                  Image.asset(logo, fit: BoxFit.fill, height: 230, width: 230),
                ],

                const SizedBox(height: 50),
                Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      //Email
                      CustomTextField(
                          controller: usernameController,
                          hintText: usernameHintText ?? "Username",
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          autofillHints: const [
                            AutofillHints.email,
                            AutofillHints.telephoneNumber,
                          ],
                          validator: usernameValidator),

                      const SizedBox(height: 14),

                      //Password
                      CustomTextField(
                          controller: passwordController,
                          autofillHints: const <String>[
                            AutofillHints.password,
                          ],
                          hintText: passwordHintText ?? "Password",
                          keyboardType: TextInputType.visiblePassword,
                          textInputAction: TextInputAction.done,
                          validator: passwordValidator),
                    ]),
                _loginButton(
                    formKey, usernameController, passwordController, context),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // InkWell(
                    //     onTap: () {},
                    //     child: Text(
                    //       "forgotPassword".tr(),
                    //       textAlign: TextAlign.center,
                    //       style: context.headline6,
                    //     )),
                  ],
                ),
                const SizedBox(
                  height: 8,
                ),

                const Divider(),
                const SizedBox(
                  height: 8,
                ),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.center,
                //   children: [
                //     Text(
                //       "haveAnInvite".tr(),
                //       style: context.headline4,
                //       textAlign: TextAlign.center,
                //     ),
                //     const SizedBox(
                //       width: 7,
                //     ),
                OutlinedButton(
                  onPressed: () {
                    onSupplierRegister.call();
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(5.0),
                    child: Text(
                      "Supplier Registration",
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 8,
                ),
                ElevatedButton(
                  onPressed: () {
                    onUserRegister.call();
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(5.0),
                    child: Text(
                      "User Registration",
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                //   ],
                // ),
              ],
            )),
          ),
        ),
      ],
    ));
  }

  _loginButton(formKey, usernameController, passwordController, context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 24, 0, 24),
      child: Button.customeActive(
        onButtonPressed: () {
          FocusScope.of(context).unfocus();
          if (formKey.currentState!.validate()) {
            formKey.currentState!.save();
            onLogin?.call((
              usernameController.text.trim(),
              passwordController.text.trim()
            ));
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.blue,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
            child: Center(
              child: Text(
                "Login",
                style: GoogleFonts.montserrat(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
