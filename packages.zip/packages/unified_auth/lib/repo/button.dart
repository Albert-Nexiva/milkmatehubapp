import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  final String? buttonText;
  final ButtonType type;
  final VoidCallback? onButtonPressed;
  final Widget? child;

  const factory Button.active({
    required String buttonText,
    VoidCallback? onButtonPressed,
  }) = _ActiveButton;

  const factory Button.customeActive({
    VoidCallback? onButtonPressed,
    Widget child,
  }) = _CustomeActiveButton;
  const factory Button.customeOutlines({
    VoidCallback? onButtonPressed,
    Widget child,
  }) = _CustomeOutlinedButton;

  const factory Button.outlined({
    String? buttonText,
    Widget? child,
    VoidCallback? onButtonPressed,
  }) = _OutlinedButton;

  const Button._(
      {required this.type,
      required this.child,
      this.buttonText,
      required this.onButtonPressed});

  @override
  Widget build(BuildContext context) {
    if (type == ButtonType.ACTIVE) {
      return TextButton(
          onPressed: onButtonPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(buttonText ?? ""),
          ));
    } else if (type == ButtonType.CUSTOME_ACTIVE) {
      return TextButton(
        style: ButtonStyle(
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ))),
        onPressed: onButtonPressed,
        child: child!,
      );
    } else if (type == ButtonType.CUSTOME_OUTLINED) {
      return OutlinedButton(
        onPressed: onButtonPressed,
        child: child!,
      );
    } else {
      return OutlinedButton(
          onPressed: onButtonPressed,
          child: Padding(
            padding: const EdgeInsets.only(left: 12, right: 12),
            child: Text(
              buttonText ?? "",
            ),
          ));
    }
  }
}

// ignore: constant_identifier_names
enum ButtonType { ACTIVE, CUSTOME_ACTIVE, OUTLINED, CUSTOME_OUTLINED }

class _ActiveButton extends Button {
  const _ActiveButton(
      {required String buttonText,
      VoidCallback? onButtonPressed,
      Widget? child})
      : super._(
            buttonText: buttonText,
            onButtonPressed: onButtonPressed,
            type: ButtonType.ACTIVE,
            child: child);
}

class _CustomeActiveButton extends Button {
  const _CustomeActiveButton({VoidCallback? onButtonPressed, Widget? child})
      : super._(
            onButtonPressed: onButtonPressed,
            type: ButtonType.CUSTOME_ACTIVE,
            child: child);
}

class _CustomeOutlinedButton extends Button {
  const _CustomeOutlinedButton({VoidCallback? onButtonPressed, Widget? child})
      : super._(
            onButtonPressed: onButtonPressed,
            type: ButtonType.CUSTOME_OUTLINED,
            child: child);
}

class _OutlinedButton extends Button {
  const _OutlinedButton(
      {String? buttonText, VoidCallback? onButtonPressed, Widget? child})
      : assert(buttonText != null || child != null,
            "Either ButtonText or Child parameter should be defined!"),
        super._(
            buttonText: buttonText,
            onButtonPressed: onButtonPressed,
            type: ButtonType.OUTLINED,
            child: child);
}
