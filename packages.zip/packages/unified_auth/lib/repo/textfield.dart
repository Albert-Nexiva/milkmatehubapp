import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

//Helpers

class CustomTextField extends StatefulWidget {
  final TextEditingController? controller;
  final double? width;
  final int? maxLength;
  final Color? fillColor;
  final String? floatingText, hintText;
  final EdgeInsets? contentPadding;
  final void Function(String? value)? onSaved, onChanged;
  final Widget? prefix;
  final bool showCursor;
  final bool autofocus;
  final bool showErrorBorder;
  final bool readOnly;
  final TextAlign textAlign;
  final IconData? suffixIcon;
  final String? suffixText;
  final InputBorder? border;
  final int? maxLines;
  final Alignment errorAlign, floatingAlign;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final Function? onTap;
  final Function()? onEditingComplete;
  final String? Function(String? value)? validator;
  final int? minLines;
  final bool editable;
  final bool capitalizeAll;
  final FocusNode? focusNode;
  final Iterable<String>? autofillHints;
  final List<TextInputFormatter>? inputFormatter;
  const CustomTextField({
    Key? key,
    this.controller,
    this.width,
    this.maxLength,
    this.floatingText,
    this.onSaved,
    this.onChanged,
    this.prefix,
    this.focusNode,
    this.autofillHints,
    this.minLines = 1,
    this.capitalizeAll = false,
    this.maxLines = 1,
    this.showCursor = true,
    this.showErrorBorder = false,
    this.autofocus = false,
    this.readOnly = false,
    this.textAlign = TextAlign.start,
    this.errorAlign = Alignment.centerRight,
    this.floatingAlign = Alignment.centerLeft,
    this.hintText,
    this.suffixIcon,
    this.suffixText,
    this.border,
    this.editable = true,
    this.onEditingComplete,
    this.fillColor,
    this.contentPadding =
        const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    required this.keyboardType,
    required this.textInputAction,
    required this.validator,
    this.onTap,
    this.inputFormatter,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  String? errorText;
  bool hidePassword = true;
  final GlobalKey<FormFieldState> fieldKey = GlobalKey<FormFieldState>();
  bool get hasFloatingText => widget.floatingText != null;

  bool get isPasswordField =>
      widget.keyboardType == TextInputType.visiblePassword;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      onTap: (widget.onTap == null) ? null : () => widget.onTap!(),
      key: fieldKey,
      textCapitalization: widget.keyboardType == TextInputType.name
          ? TextCapitalization.sentences
          : widget.capitalizeAll
              ? TextCapitalization.characters
              : TextCapitalization.none,
      controller: widget.controller,
      textAlign: widget.textAlign,
      minLines: widget.minLines,
      maxLines: widget.maxLines,
      enabled: widget.editable,
      autofocus: widget.autofocus,
      autofillHints: widget.autofillHints,
      focusNode: widget.focusNode,
      maxLength: widget.maxLength,
      keyboardType: widget.keyboardType,
      onEditingComplete: widget.onEditingComplete,
      textInputAction: widget.textInputAction,
      showCursor: widget.showCursor,
      readOnly: widget.readOnly,
      maxLengthEnforcement: MaxLengthEnforcement.enforced,
      textAlignVertical: TextAlignVertical.center,
      autovalidateMode: AutovalidateMode.disabled,
      obscureText: isPasswordField && hidePassword,
      validator: _runValidator,
      onFieldSubmitted: _runValidator,
      onSaved: _onSaved,
      onChanged: _onChanged,
      decoration: InputDecoration(
        hintText: widget.hintText,
        // hintStyle: context.headline4.copyWith(fontSize: 13),
        prefixIcon: widget.prefix,
        contentPadding: widget.contentPadding,
        border: widget.border,
        fillColor: widget.fillColor,
        isDense: true,
        filled: true,
        counterText: '',
        suffixIcon: isPasswordField
            ? InkWell(
                onTap: _togglePasswordVisibility,
                child: Icon(
                  hidePassword ? Icons.visibility_off : Icons.visibility,
                  color:
                      !hidePassword ? Colors.red : Colors.grey.withOpacity(0.5),
                  size: 22,
                ),
              )
            : Icon(widget.suffixIcon),
        suffixText: widget.suffixText,
      ),
      inputFormatters: widget.inputFormatter,
    );
  }

  void _onChanged(String value) {
    if (widget.onChanged != null) {
      _runValidator(value);
      widget.onChanged!(value);
    }
  }

  void _onSaved(String? value) {
    value = value!.trim();
    widget.controller?.text = value;
    widget.onSaved?.call(value);
  }

  String? _runValidator(String? value) {
    final error = widget.validator?.call(value!.trim());
    setState(() {
      errorText = error;
    });
    return error;
  }

  void _togglePasswordVisibility() {
    setState(() {
      hidePassword = !hidePassword;
    });
  }
}
