import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class BackgroundContainer extends StatelessWidget {
  final List<Widget> children;
  final EdgeInsets? padding;
  final String background;

  const BackgroundContainer({
    Key? key,
    required this.children,
    this.padding,
    required this.background,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned.fill(
          child: (background.contains('svg'))
              ? SvgPicture.asset(background, fit: BoxFit.fill)
              : Image.asset(background, fit: BoxFit.fill)),
      Positioned.fill(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: ListView(
                // crossAxisAlignment: CrossAxisAlignment.center,
                // mainAxisAlignment: MainAxisAlignment.center,
                // mainAxisSize: MainAxisSize.min,
                shrinkWrap: true,
                children: children),
          ),
        ),
      )
    ]);
  }
}
