import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

//Widgets

class Logo extends StatelessWidget {
  final String icon;
  const Logo({required this.icon, super.key});

  @override
  Widget build(BuildContext context) {
    return Hero(
        tag: "hero-logo",
        child: (icon.contains('svg'))
            ? SvgPicture.asset(
                icon,
                fit: BoxFit.contain,
                height: 100,
                width: 100,
              )
            : Image.asset(
                icon,
                fit: BoxFit.contain,
                height: 100,
                width: 100,
              ));
  }
}

class UnifiedSplashScreen extends HookConsumerWidget {
  final String icon;

  const UnifiedSplashScreen({required this.icon, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Spacer(),
              Logo(
                icon: icon,
              ),
              const Spacer()
            ]),
      ),
    );
  }
}
